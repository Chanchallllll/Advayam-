# Advayam

Advayam is a VS Code extension for creating embedded and microcontroller starter projects from a guided wizard, then managing the resulting PlatformIO workspace from the editor.

## Features

- Open the project wizard from the Command Palette or the Advayam activity bar.
- Create projects for ESP32, Arduino, and MicroPython workflows.
- Choose from supported boards during project creation.
- Generate starter files plus an `advayam.ini` metadata file for each project.
- Use editor and view actions for Build, Upload, Monitor, Clean, and Open `platformio.ini`.
- Show ESP32-only build and upload controls only when the current workspace contains a PlatformIO project configured for `espressif32`.
- Fetch available serial ports inside the wizard.

## Supported Project Types

The wizard currently supports these project families:

- ESP32
- Arduino
- MicroPython

## Supported Boards

Each project family exposes board-specific options in the wizard:

- ESP32: ESP32 DevKit, ESP32 S3 DevKit M1
- Arduino: Arduino Uno, Arduino Nano
- MicroPython: Raspberry Pi Pico, ESP32 MicroPython

## Generated Output

The project generator creates a starter file for the selected board type and writes a project README and metadata file:

- ESP32 projects create `platformio.ini` and `src/main.cpp` style PlatformIO scaffolding.
- Arduino projects create a `main.ino` sketch.
- MicroPython projects create a `main.py` script.
- Every generated project includes a project `README.md` with the name, description, author, and board.
- Every generated project includes `advayam.ini` with the stored wizard metadata.

## Commands

- `advayam.openWizard` - Open the project wizard.
- `advayam.build` - Run `pio run`.
- `advayam.upload` - Run `pio run --target upload`.
- `advayam.monitor` - Run `pio device monitor`.
- `advayam.clean` - Run `pio run --target clean`.
- `advayam.templateLedBlink` - Select the LED Blink template.
- `advayam.templateWiFiServer` - Select the WiFi Web Server template.
- `advayam.templateMQTT` - Select the MQTT Client template.
- `advayam.templateDHT11` - Select the DHT11 Sensor template.
- `advayam.templateOLED` - Select the OLED Display template.

## Requirements

- Visual Studio Code 1.120.0 or later.
- Python installed and available on `PATH`.
- PlatformIO CLI for build, upload, monitor, and clean actions.

## Usage

1. Open the Command Palette and run `Advayam : Open Project Wizard`.
2. Pick a project folder and enter the project details.
3. Choose a project family and, if applicable, select a board.
4. Create the project and open the generated workspace.
5. Use the Advayam view or the editor title actions to build, upload, monitor, or clean the project.

## Version

0.0.1