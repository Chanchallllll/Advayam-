const createProject =
require('./generators/createProject');
const { SerialPort } = require('serialport');
const vscode = require('vscode');
const fs = require('fs');
const path = require('path');
const RECENT_PROJECTS_KEY = 'advayam.recentProjects';
let advayamTerminal;
const { exec } = require('child_process');
function checkPlatformIO() {
    return new Promise((resolve) => {
        exec('pio --version', (error) => {
            resolve(!error);
        });
    });
}
function checkPython() {
    return new Promise((resolve) => {
        exec('where python', (error, stdout) => {
            if (error) {
                resolve(false);
                return;
            }

            if (stdout.includes('Python313')) {
                resolve(true);
            } else {
                resolve(false);
            }
        });
    });
}

function installPlatformIO(terminal) {
    return new Promise((resolve) => {
        terminal.sendText('pip install platformio');
        terminal.sendText('echo "Installing PlatformIO CLI..."');
        
        // Check after 45 seconds if PlatformIO is installed
        setTimeout(async () => {
            const installed = await checkPlatformIO();
            if (installed) {
                vscode.window.showInformationMessage('PlatformIO CLI installed successfully!');
                resolve(true);
            } else {
                // Try alternative installation method
                terminal.sendText('python -m pip install platformio');
                setTimeout(async () => {
                    const retryInstalled = await checkPlatformIO();
                    if (retryInstalled) {
                        vscode.window.showInformationMessage('PlatformIO CLI installed successfully!');
                        resolve(true);
                    } else {
                        vscode.window.showWarningMessage('PlatformIO CLI installation could not be verified.');
                        resolve(false);
                    }
                }, 30000);
            }
        }, 45000);
    });
}

(async () => {
    try {
        const pythonInstalled = await checkPython();

        if (!pythonInstalled) {
            // Install Python
            vscode.window.showInformationMessage(
                'Python is required for Advayam. Installing now...'
            );
            
            const terminal = vscode.window.createTerminal('Advayam Setup');
            terminal.show(true);
            
            terminal.sendText('winget install Python.Python.3.13 --accept-package-agreements --accept-source-agreements');
            // terminal.sendText('echo "Python installation in progress. Please wait..."');
            
            // Wait for Python installation to complete
            await new Promise((resolve) => {
                setTimeout(async () => {
                    const installed = await checkPython();
                    if (installed) {
                        vscode.window.showInformationMessage('Python installed successfully!');
                        resolve();
                    } else {
                        vscode.window.showWarningMessage('Python installation could not be verified.');
                        resolve();
                    }
                }, 30000);
            });
        } else {
            vscode.window.showInformationMessage('Python is installed.');
        }

        // Check and install PlatformIO
        const pioInstalled = await checkPlatformIO();
        
        if (!pioInstalled) {
            vscode.window.showInformationMessage(
                'PlatformIO CLI is required. Installing now...'
            );
            
            // Get or create terminal
            let terminal = vscode.window.terminals.find(t => t.name === 'Advayam Setup');
            if (!terminal) {
                terminal = vscode.window.createTerminal('Advayam Setup');
            }
            terminal.show(true);
            
            // Install PlatformIO
            await installPlatformIO(terminal);
        } else {
            vscode.window.showInformationMessage('PlatformIO CLI is installed.');
        }

    } catch (error) {
        vscode.window.showErrorMessage(
            `Advayam setup error: ${error.message}`
        );
        console.error('Setup error:', error);
    }
})();
    
function getAdvayamTerminal()
{
    if(!advayamTerminal)
    {
        advayamTerminal =
        vscode.window.createTerminal(
            'Advayam'
        );
    }

    return advayamTerminal;
}
async function promptReplaceMainFile(templateFile)
{
    const answer =
    await vscode.window.showWarningMessage(
        'Replace current main file with this template?',
        { modal: true },
        'Yes',
        'No'
    );

    if(answer !== 'Yes')
    {
        return;
    }

    try
    {
        const workspace =
            vscode.workspace.workspaceFolders?.[0];

        if(!workspace)
        {
            vscode.window.showErrorMessage(
                'No project opened'
            );

            return;
        }
        let fileExtension = '';
        let targetFile = '';
        let templateFolder = '';

        if(fs.existsSync(
            path.join(
                workspace.uri.fsPath,
                'src',
                'main.cpp'
            )
        ))
        {
            targetFile =
                path.join(
                    workspace.uri.fsPath,
                    'src',
                    'main.cpp'
                );

            templateFolder = 'cpp';
            fileExtension = 'cpp';
        }

        else if(fs.existsSync(
            path.join(
                workspace.uri.fsPath,
                'main.ino'
            )
        ))
        {
            targetFile =
                path.join(
                    workspace.uri.fsPath,
                    'main.ino'
                );
            fileExtension = 'ino';
            templateFolder = 'ino';
        }

        else if(fs.existsSync(
            path.join(
                workspace.uri.fsPath,
                'main.py'
            )
        ))
        {
            targetFile =
                path.join(
                    workspace.uri.fsPath,
                    'main.py'
                );
            fileExtension = 'py';
            templateFolder = 'py';
        }

        else
        {
            vscode.window.showErrorMessage(
                'No supported main file found'
            );

            return;
}

const templatePath =
path.join(
    __dirname,
    'templates',
    templateFolder,
    `${templateFile}.${fileExtension}`
);
        if(!fs.existsSync(templatePath))
        {
            vscode.window.showErrorMessage(
                'Template file not found'
            );

            return;
        }

        const templateCode =
            fs.readFileSync(
                templatePath,
                'utf8'
            );

        fs.writeFileSync(
    targetFile,
    templateCode
);
        const document =
    await vscode.workspace.openTextDocument(
        targetFile
    );

        await vscode.window.showTextDocument(
        document
        );

        vscode.window.showInformationMessage(
            'Template applied successfully'
        );
    }

    catch(error)
    {
        vscode.window.showErrorMessage(
            error.message
        );
    }
}

async function activate(context)
{
    const pythonVerified =
context.globalState.get('advayam.pythonVerified');

const pioVerified =
context.globalState.get('advayam.pioVerified');
if (!pythonVerified)
{
    await checkPython();

    await context.globalState.update(
        'advayam.pythonVerified',
        true
    );
}

if (!pioVerified)
{
    await checkPlatformIO();

    await context.globalState.update(
        'advayam.platformioVerified',
        true
    );
}
function addRecentProject(context, projectPath)
{
    let projects =
        context.globalState.get(
            RECENT_PROJECTS_KEY,
            []
        );

    projects =
        projects.filter(
            p => p !== projectPath
        );

    projects.unshift(projectPath);

    projects = projects.slice(0, 3);

    context.globalState.update(
        RECENT_PROJECTS_KEY,
        projects
    );
}

function getRecentProjects(context)
{
    return context.globalState.get(
        RECENT_PROJECTS_KEY,
        []
    );
}
    class SectionItem extends vscode.TreeItem
    {
        constructor(label)
        {
            super(
                label,
                vscode.TreeItemCollapsibleState.Expanded
            );
        }
    }

class InfoItem extends vscode.TreeItem
{
    constructor(label, icon)
    {
        super(
            label,
            vscode.TreeItemCollapsibleState.None
        );

        this.iconPath =
            new vscode.ThemeIcon(icon);
    }
}

class ControlItem extends vscode.TreeItem
{
    constructor(label, command, icon)
    {
        super(
            label,
            vscode.TreeItemCollapsibleState.None
        );

        this.command =
        {
            command,
            title: label
        };

        this.iconPath =
            new vscode.ThemeIcon(icon);
    }
}
class AdvayamProvider
{
    constructor()
    {
        this._onDidChangeTreeData =
            new vscode.EventEmitter();

        this.onDidChangeTreeData =
            this._onDidChangeTreeData.event;
    }

    refresh()
    {
        this._onDidChangeTreeData.fire();
    }
    getTreeItem(item)
    {
        return item;
    }

    getChildren(element)
    {
        if(!element)
        {
            const items =
            [
                new SectionItem('Project'),
                new SectionItem('Actions')
            ];

            const workspace =
                vscode.workspace.workspaceFolders?.[0];

            
            items.push(
                new SectionItem('Templates')
            );

            items.push(
                new SectionItem('Tools')
            );

            return items;
        }

        if(element.label === 'Project')
        {
            const info =
                getProjectInfo();

            if(!info)
            {
                return [
                    new InfoItem(
                        'No Project',
                        'warning'
                    )
                ];
            }

            return [
                new InfoItem(
                    info.board,
                    'device-mobile'
                ),

                new InfoItem(
                    info.framework,
                    'gear'
                ),

                new InfoItem(
                        getConnectedPort(),
                        'plug'
                    )
            ];
        }

        if(element.label === 'Actions')
        {
            return [
                new ControlItem(
                    'Build',
                    'advayam.build',
                    'tools'
                ),

                new ControlItem(
                    'Upload',
                    'advayam.upload',
                    'arrow-up'
                ),

                new ControlItem(
                    'Monitor',
                    'advayam.monitor',
                    'terminal'
                ),

                new ControlItem(
                    'Clean',
                    'advayam.clean',
                    'trash'
                )
            ];
        }

        if(element.label === 'Templates')
        {
            return [
                new ControlItem(
                    'LED Blink',
                    'advayam.templateLedBlink',
                    'lightbulb'
                ),

                new ControlItem(
                    'WiFi Web Server',
                    'advayam.templateWiFiServer',
                    'globe'
                ),

                new ControlItem(
                    'MQTT Client',
                    'advayam.templateMQTT',
                    'broadcast'
                ),

                new ControlItem(
                    'DHT11 Sensor',
                    'advayam.templateDHT11',
                    'pulse'
                ),

                new ControlItem(
                    'OLED Display',
                    'advayam.templateOLED',
                    'device-desktop'
                )
            ];
        }

        if(element.label === 'Tools')
        {
            return [
                new ControlItem(
                    'New Project',
                    'advayam.openWizard',
                    'add'
                ),

                new ControlItem(
                    'Open platformio.ini',
                    'advayam.openPlatformio',
                    'file-code'
                )
            ];
        }

        return [];
    }
}
    const provider =
    new AdvayamProvider();
    setInterval(
        () =>
        {
            provider.refresh();
        },
        3000
    );

    context.subscriptions.push(
        vscode.window.registerTreeDataProvider(
            'advayamControls',
            provider
        )
    );
    async function updateProjectContext()
{
    const workspaceFolders =
        vscode.workspace.workspaceFolders;

    if (!workspaceFolders)
    {
        await vscode.commands.executeCommand(
            'setContext',
            'advayam.isESP32Project',
            true
        );
        return;
    }

    await vscode.commands.executeCommand(
        'setContext',
        'advayam.isESP32Project',
        true
    );
}
    updateProjectContext();
    vscode.workspace.onDidChangeWorkspaceFolders(
        () =>
        {
            updateProjectContext();
            provider.refresh();
        }
    );
    
     const buildCommand =
vscode.commands.registerCommand(
    'advayam.build',
    async () => {
        const terminal =
        getAdvayamTerminal();

        terminal.show();
        terminal.sendText('pio run');
    }
);

const uploadCommand =
vscode.commands.registerCommand(
    'advayam.upload',
    async () => {
        const terminal =
        getAdvayamTerminal();

        terminal.show();
        terminal.sendText(
            'pio run --target upload'
        );
    }
);
const cleanCmd =
vscode.commands.registerCommand(
    'advayam.clean',
    () =>
    {
        const terminal =
        getAdvayamTerminal();

        terminal.show();

        terminal.sendText(
            'pio run --target clean'
        );
    }
);

context.subscriptions.push(
    buildCommand,
    uploadCommand,
    cleanCmd
);

const ledBlinkCmd =
vscode.commands.registerCommand(
    'advayam.templateLedBlink',
    () =>
    {
        promptReplaceMainFile(
            'led'
        );
    }
);
const wifiCmd =
vscode.commands.registerCommand(
    'advayam.templateWiFiServer',
    () =>
    {
        promptReplaceMainFile(
            'wifi'
        );
    }
);

const mqttCmd =
vscode.commands.registerCommand(
    'advayam.templateMQTT',
    () =>
    {
        promptReplaceMainFile(
            'mqttclient'
        );
    }
);

const dhtCmd =
vscode.commands.registerCommand(
    'advayam.templateDHT11',
    () =>
    {
        promptReplaceMainFile(
            'dht11sensor'
        );
    }
);

const oledCmd =
vscode.commands.registerCommand(
    'advayam.templateOLED',
    () =>
    {
        promptReplaceMainFile(
            'oled'
        );
    }
);

context.subscriptions.push(
    ledBlinkCmd,
    wifiCmd,
    mqttCmd,
    dhtCmd,
    oledCmd
);

    const monitorCmd =
    vscode.commands.registerCommand(
        'advayam.monitor',
        () =>
        {
            const terminal =
            getAdvayamTerminal();

            terminal.show();

            terminal.sendText(
                'pio device monitor'
            );
        }
    );
    context.subscriptions.push(monitorCmd);

    const openPlatformioCmd =
    vscode.commands.registerCommand(
        'advayam.openPlatformio',
        async () =>
        {
            const root =
            vscode.workspace.workspaceFolders?.[0];

            if(!root)
            {
                return;
            }

            const file =
            vscode.Uri.file(
                path.join(
                    root.uri.fsPath,
                    'platformio.ini'
                )
            );

            const doc =
            await vscode.workspace.openTextDocument(
                file
            );

            vscode.window.showTextDocument(doc);
        }
    );

    context.subscriptions.push(
        openPlatformioCmd
);
	const disposable = vscode.commands.registerCommand(
		'advayam.openWizard',
		() =>
		{
			const panel = vscode.window.createWebviewPanel(
				'advayamWizard',
				'Advayam Project Wizard',
				vscode.ViewColumn.One,
				{
					enableScripts: true,
					localResourceRoots: [
						vscode.Uri.joinPath(
							context.extensionUri,
							'webview-ui',
							'dist'
						)
					]
				}
			);
            
			panel.webview.onDidReceiveMessage(
				async (message) =>
				{
                
					switch(message.command)
					{   
                        case 'getPorts':

                        try {

                            const ports = await SerialPort.list();

                            panel.webview.postMessage({

                                command: 'ports',

                                ports: ports.map(port => port.path)

                            });

                        }

                        catch(error) {

                            vscode.window.showErrorMessage(
                                'Unable to fetch ports'
                            );
                        }

                        break;
						case 'selectFolder':

							const folder =
							await vscode.window.showOpenDialog({
								canSelectFolders:true,
								canSelectFiles:false,
								canSelectMany:false,
								openLabel:'Select Project Folder'
							});

							if(folder)
							{
								panel.webview.postMessage({
									command:'folderSelected',
									path:folder[0].fsPath
								});
							}

							break;
                        

                        case 'openExistingProject':

                        const folders =
                        await vscode.window.showOpenDialog({
                            canSelectFolders: true,
                            canSelectFiles: false,
                            canSelectMany: false,
                            openLabel: 'Open Project'
                        });

                        if(folders)
                        {
                            vscode.commands.executeCommand(
                                'vscode.openFolder',
                                folders[0],
                                false
                            );
                        }

                        break;    
                        case 'getRecentProjects':

                        panel.webview.postMessage({
                            command: 'recentProjects',
                            projects:
                            getRecentProjects(context)
                        });

                        break;
                        case 'openRecentProject':

                        vscode.commands.executeCommand(
                            'vscode.openFolder',
                            vscode.Uri.file(
                                message.projectPath
                            ),
                            false
                        );

                        break;
						case 'createProject':
                                console.log(message);
							try
							{   
								const projectPath =
								await createProject(
									message
								);
                                addRecentProject(
                                context,
                                projectPath
                                );
								vscode.window.showInformationMessage(
									'Project Created Successfully'
								);
                                panel.dispose();
								vscode.commands.executeCommand(
                                'vscode.openFolder',
                                vscode.Uri.file(projectPath),
                                false
                                );
                                provider.refresh(); 
                                
							}
							catch(error)
							{
								vscode.window.showErrorMessage(
									error.message
								);
							}
    						break;
                            
					}
				}
			);

			panel.webview.html = getWebviewContent(
				panel.webview,
				context.extensionUri
			);
		}
	);

	context.subscriptions.push(disposable);
}
function getProjectInfo()
{
    const workspace =
        vscode.workspace.workspaceFolders?.[0];

    if(!workspace)
    {
        return null;
    }

    const iniPath =
        path.join(
            workspace.uri.fsPath,
            'platformio.ini'
        );

    if(!fs.existsSync(iniPath))
    {
        return null;
    }

    const content =
        fs.readFileSync(
            iniPath,
            'utf8'
        );

    let board = 'Unknown';
    let framework = 'Unknown';

    const boardMatch =
        content.match(
            /board\s*=\s*(.+)/
        );

    const frameworkMatch =
        content.match(
            /framework\s*=\s*(.+)/
        );

    if(boardMatch)
    {
        board = boardMatch[1].trim();
    }

    if(frameworkMatch)
    {
        framework = frameworkMatch[1].trim();
    }

    return {
        board,
        framework
    };
}
const { execSync } = require('child_process');

function getConnectedPort()
{
    try
    {
        const output =
            execSync(
                'python -m platformio device list',
                { encoding: 'utf8' }
            );

        const match =
            output.match(
                /(COM\d+)/
            );

        if(match)
        {
            return match[1];
        }

        return 'No Device';
    }
    catch(error)
    {
        return 'No Device';
    }
}

function getWebviewContent(webview, extensionUri)
{
	const distPath = vscode.Uri.joinPath(
		extensionUri,
		'webview-ui',
		'dist'
	);

	const indexPath = path.join(
		distPath.fsPath,
		'index.html'
	);

	let html = fs.readFileSync(
		indexPath,
		'utf8'
	);

	const assetsPath = webview.asWebviewUri(
		vscode.Uri.joinPath(
			extensionUri,
			'webview-ui',
			'dist'
		)
	);

	html = html.replaceAll(
		'./assets/',
		`${assetsPath}/assets/`
	);

	html = html.replaceAll(
		'./images/',
		`${assetsPath}/images/`
	);

	return html;
}

function deactivate()
{
}

module.exports = {
	activate,
	deactivate
};