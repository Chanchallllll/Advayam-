const fs = require('fs');

const path = require('path');

function createArduinoUno(projectPath)
{
    fs.writeFileSync(

        path.join(
            projectPath,
            'main.ino'
        ),

`void setup()
{
    Serial.begin(9600);
    pinMode(LED_BUILTIN, OUTPUT);

    Serial.println("Advayam Project Initialized");
    Serial.println("Target Board: Arduino Uno");
}

void loop()
{
    digitalWrite(LED_BUILTIN, HIGH);
    delay(1000);

    digitalWrite(LED_BUILTIN, LOW);
    delay(1000);
}
`
    );
}

module.exports =
createArduinoUno;