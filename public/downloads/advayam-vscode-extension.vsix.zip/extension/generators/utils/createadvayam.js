const fs = require('fs');
const path = require('path');

function safe(value)
{
    return value && value.trim() !== ''
        ? value
        : 'null';
}

function createAdvayam(projectPath, data)
{
    const content =
`[project]
name=${safe(data.projectName)}
description=${safe(data.description)}
author=${safe(data.author)}
project_type=${safe(data.projectType)}
board_type=${safe(data.boardType)}
port=${safe(data.port)}
`;

    fs.writeFileSync(
        path.join(projectPath, 'advayam.ini'),
        content
    );
}

module.exports = createAdvayam;