const fs = require('fs');

const path = require('path');

function createReadme(projectPath,data)
{
    const content = `# ${data.projectName}

## Description

${data.description}

## Author

${data.author}

## Board

${data.boardType}
`;

    fs.writeFileSync(

        path.join(
            projectPath,
            'README.md'
        ),

        content
    );
}

module.exports = createReadme;