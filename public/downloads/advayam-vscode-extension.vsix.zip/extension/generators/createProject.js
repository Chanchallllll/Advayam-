const fs = require('fs');
const path = require('path');

const createESP32DevKit =
require('./esp32/esp32Devkit');

const createESP32S3DevKitM1 =
require('./esp32/esp32S3DevKitM1');

const createArduinoUno =
require('./arduino/arduinoUno');

const createArduinoNano =
require('./arduino/arduinoNano');

const createRaspberryPico =
require('./micropython/raspberryPico');

const createESP32MicroPython =
require('./micropython/esp32MicroPython');

const createReadme =
require('./utils/createReadme');

const createAdvayam =
require('./utils/createAdvayam');

async function createProject(data)
{
 const projectPath =
 path.join(
 data.projectFolder,
 data.projectName
 );

 if(fs.existsSync(projectPath))
 {
 throw new Error(
 'Project already exists'
 );
 }

 fs.mkdirSync(
 projectPath,
 {recursive:true}
 );

 switch(data.boardType)
 {
 case 'esp32devkit':

 createESP32DevKit(
 projectPath,
 data
 );

 break;

 case 'esp32s3devkitm1':

 createESP32S3DevKitM1(
 projectPath,
 data
 );

 break;

 case 'uno':

 createArduinoUno(
 projectPath,
 data
 );

 break;

 case 'nano':

 createArduinoNano(
 projectPath,
 data
 );

 break;

 case 'pico':

 createRaspberryPico(
 projectPath,
 data
 );

 break;

 case 'esp32micro':

 createESP32MicroPython(
 projectPath,
 data
 );

 break;
 }

 createReadme(
 projectPath,
 data
 );

createAdvayam(projectPath, data);

 return projectPath;
}

module.exports =
createProject;