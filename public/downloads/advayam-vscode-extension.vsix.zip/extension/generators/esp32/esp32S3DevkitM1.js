const fs = require('fs');

const path = require('path');

function createESP32S3DevKitM1(projectPath)
{
    const srcFolder =
    path.join(
        projectPath,
        'src'
    );

    fs.mkdirSync(
        srcFolder,
        {recursive:true}
    );

    fs.writeFileSync(

        path.join(
            srcFolder,
            'main.cpp'
        ),

`#include <Arduino.h>

#define LED_PIN 2  // Verify LED GPIO for your ESP32-S3 board

void setup()
{
    Serial.begin(115200);
    pinMode(LED_PIN, OUTPUT);

    Serial.println("Advayam Project Initialized");
    Serial.println("Target Board: ESP32-S3 DevKitM-1");
}

void loop()
{
    digitalWrite(LED_PIN, HIGH);
    delay(1000);

    digitalWrite(LED_PIN, LOW);
    delay(1000);
}   
`
    );

    fs.writeFileSync(

        path.join(
            projectPath,
            'platformio.ini'
        ),

`[env:esp32-s3-devkitm-1]
platform = espressif32
board = esp32-s3-devkitm-1
build_flags=-DARDUINO_USB_CDC_ON_BOOT=1
framework = arduino
`
    );
}

module.exports =
createESP32S3DevKitM1;