const fs = require('fs');
const path = require('path');

function createESP32DevKit(
projectPath,
data
)
{
fs.mkdirSync(

path.join(
projectPath,
'src'
),

{recursive:true}

);

fs.writeFileSync(

path.join(
projectPath,
'platformio.ini'
),

`[env:esp32dev]
platform = espressif32
board = esp32dev
build_flags=-DARDUINO_USB_CDC_ON_BOOT=1
framework = arduino`

);

fs.writeFileSync(

path.join(
projectPath,
'src',
'main.cpp'
),

`#include <Arduino.h>

#define LED_PIN 2  // Verify LED GPIO for your ESP32 board

void setup()
{
    Serial.begin(115200);
    pinMode(LED_PIN, OUTPUT);

    Serial.println("Advayam Project Initialized");
    Serial.println("Target Board: ESP32 Dev Module");
}

void loop()
{
    digitalWrite(LED_PIN, HIGH);
    delay(1000);

    digitalWrite(LED_PIN, LOW);
    delay(1000);
}
`

);
}

module.exports =
createESP32DevKit;