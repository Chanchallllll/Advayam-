const fs = require('fs');

const path = require('path');

function createESP32MicroPython(projectPath)
{
    fs.writeFileSync(

        path.join(
            projectPath,
            'main.py'
        ),

`from machine import Pin
from time import sleep

print("Advayam Project Initialized")
print("Target Board: ESP32")
print("Framework: MicroPython")

led = Pin(2, Pin.OUT)  # Verify LED GPIO for your ESP32 board

while True:
    led.value(not led.value())
    sleep(1)
`
    );
}

module.exports =
createESP32MicroPython;