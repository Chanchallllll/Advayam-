const fs = require('fs');

const path = require('path');

function createRaspberryPico(projectPath)
{
    fs.writeFileSync(

        path.join(
            projectPath,
            'main.py'
        ),

`from machine import Pin
from time import sleep

print("Advayam Project Initialized")
print("Target Board: Raspberry Pi Pico")
print("Framework: MicroPython")

led = Pin(25, Pin.OUT)  # Onboard LED on Pico

while True:
    led.toggle()
    sleep(1)
`
    );
}

module.exports =
createRaspberryPico;