import { useState } from 'react';
import vscode from './vscode';
import BoardTypePage from './pages/BoardTypePage';
import WelcomePage from "./pages/WelcomePage";
import ProjectTypePage from './pages/ProjectTypePage';
import ProjectDetailsPage from './pages/ProjectDetailsPage';
import './App.css';

function App()
{
    const [errorMessage, setErrorMessage] =
    useState('');

    const [port, setPort] = useState("");

    const [availablePorts, setAvailablePorts] = useState([]);

    const [projectName,setProjectName] =
    useState('');

    const [description,setDescription] =
    useState('');

    const [author,setAuthor] =
    useState('');

    const [projectFolder,setProjectFolder] =
    useState('');

    const [step,setStep] =
    useState(0);

    const [selectedType,setSelectedType] =
    useState('');

    //for boardtype
    const [boardType,setBoardType] =
    useState('');

    return(
        <div className="app-shell">

                        <div
                    className={
                    step === 0
                    ?
                    "wizard-container welcome-layout"
                    :
                    "wizard-container"
                }
                >
                {
                    step > 0 &&
                <>
                    {
                        step !== 1 &&
                        <div className="wizard-header">

                            <h1>ADVAYAM</h1>

                            <p>Smart Project Wizard</p>

                        </div>
                    }

                    <div className="progress-container">

                        <div className={
                            step >= 1
                            ? "circle active"
                            : "circle"
                        }>
                            1
                        </div>

                        <div className={
                            step >= 2
                            ? "line active"
                            : "line"
                        }></div>

                        <div className={
                            step >= 2
                            ? "circle active"
                            : "circle"
                        }>
                            2
                        </div>

                        <div className={
                            step >= 3
                            ? "line active"
                            : "line"
                        }></div>

                        <div className={
                            step >= 3
                            ? "circle active"
                            : "circle"
                        }>
                            3
                        </div>

                    </div>
                </>
                }
                {
                    step === 0 &&
                    <WelcomePage
                        nextStep={() =>
                            setStep(1)
                        }
                    />
            }

                {
                    step === 1&&
                    <ProjectDetailsPage

                        selectedType={selectedType}


                        projectName={projectName}
                        setProjectName={setProjectName}

                        description={description}
                        setDescription={setDescription}

                        author={author}
                        setAuthor={setAuthor}

                        port={port}

                        setPort={setPort}

                        availablePorts={availablePorts}

                        setAvailablePorts={setAvailablePorts}
                        projectFolder={projectFolder}
                        setProjectFolder={setProjectFolder}
                        prevStep={() => setStep(0)}
                        nextStep={() =>
                        setStep(2)}

                        errorMessage={errorMessage}
                        setErrorMessage={setErrorMessage}
                    />
                    
                }

                {
                    step === 2 &&
                    <ProjectTypePage
                        selectedType={selectedType}
                        setSelectedType={setSelectedType}
                        prevStep={() =>
                        setStep(1)}

                        nextStep={() =>
                        setStep(3)}
                    />
                }
                {
                    step === 3 &&

                <BoardTypePage

        selectedType={selectedType}

    boardType={boardType}

    setBoardType={setBoardType}

    prevStep={()=>

    setStep(2)

    }

    createProject={() => {
    vscode.postMessage({
        command: 'createProject',
        projectType: selectedType,
        boardType,
        projectName,
        description,
        author,
        port,
        projectFolder
    });
}}

/>

}

            </div>

        </div>
    );
}

export default App;