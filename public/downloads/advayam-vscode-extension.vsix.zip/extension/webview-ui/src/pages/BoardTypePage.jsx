import esp32DevkitImg from '../assets/esp32devkit.png';

import esp32S3Img from '../assets/esp32s3.png';

import arduinoUnoImg from '../assets/arduino-uno.png';

import arduinoNanoImg from '../assets/arduino-nano.png';

import picoImg from '../assets/raspberry-pico.png';

import esp32MicroImg from '../assets/esp32-micropython.png';

function BoardTypePage({
    selectedType,

    boardType,

    setBoardType,

    prevStep,

    createProject
})
{
    let boards = [];

    if(selectedType === 'esp32')
    {
        boards = [

{
id:'esp32devkit',

name:'ESP32 DevKit',

image:esp32DevkitImg

},

{

id:'esp32s3devkitm1',

name:'ESP32 S3 DevKit M1',

image:esp32S3Img

}

];
    }

    if(selectedType === 'arduino')
    {
        boards = [

{

id:'uno',

name:'Arduino Uno',

image:arduinoUnoImg

},

{

id:'nano',

name:'Arduino Nano',

image:arduinoNanoImg

}

];
    }

    if(selectedType === 'micropython')
    {
        boards = [

{

id:'pico',

name:'Raspberry Pi Pico',

image:picoImg

},

{

id:'esp32micro',

name:'ESP32 MicroPython',

image:esp32MicroImg

}

];
    }

    return(

        <div>

            <h1>

                Select Board

            </h1>

            <div className="card-container">

            {

                boards.map(

                    board => (

                    <div

                    key={board.id}

                    className={

                    boardType === board.id

                    ?

                    "tech-card selected"

                    :

                    "tech-card"

                    }

                    onClick={()=>

                    setBoardType(

                    board.id

                    )

                    }

                    >

                        <img

                    src={board.image}

                    style={{

                    width:'200px',

                    height:'200px'

                    }}

                    />
                        <h3>

                        {board.name}

                        </h3>

                    </div>

                    )

                )

            }

            </div>

            <div className="button-group">

                <button 

                onClick={prevStep}

                >

                    Back

                </button>

                <button

                onClick={createProject}

                >

                    Create Project

                </button>

            </div>

        </div>
    );
}

export default BoardTypePage;