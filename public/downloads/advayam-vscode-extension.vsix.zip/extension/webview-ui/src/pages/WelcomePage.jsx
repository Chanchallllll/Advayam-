
import { useEffect, useState } from "react";
import vscode from "../vscode";
function WelcomePage({ nextStep })
{
    const [recentProjects, setRecentProjects] =
    useState([]);
    useEffect(() =>
        {
            const listener = (event) =>
            {
                const message = event.data;

                if(
                    message.command ===
                    'recentProjects'
                )
                {
                    setRecentProjects(
                        message.projects
                    );
                }
            };

            window.addEventListener(
                'message',
                listener
            );

            vscode.postMessage({
                command:
                'getRecentProjects'
            });

            return () =>
            {
                window.removeEventListener(
                    'message',
                    listener
                );
            };
    }, []);
    const handleOpenProject = () =>
    {
        vscode.postMessage({
            command: "openExistingProject"
        });
    };

    return (
        <div className="welcome-home">

            <div className="hero-card">

                <h1>
                    Welcome to Advayam
                </h1>

                <p>
                    Smart Embedded Development Platform
                </p>

            </div>

            <div className="section-title">
                QUICK ACTIONS
            </div>

            <div className="quick-actions">

                <button
                    className="action-card"
                    onClick={nextStep}
                >
                    Create New Project
                </button>

                <button
                    className="action-card"
                    onClick={handleOpenProject}
                >
                    Open Existing Project
                </button>

            </div>

            <div className="section-title">
                RECENT PROJECTS
            </div>

            <div className="recent-projects">

            {
                recentProjects.length === 0
                ?
                (
                    <div className="project-item">
                        <h3>No Recent Projects</h3>
                        <p>Create or open a project</p>
                    </div>
                )
                :
                recentProjects.map((project) => (

                    <div
                        key={project}
                        className="project-item"
                        onClick={() =>
                        {
                            vscode.postMessage({
                                command:
                                'openRecentProject',

                                projectPath:
                                project
                            });
                        }}
                        style={{
                            cursor:'pointer'
                        }}
                    >

                        <h3>
                            {
                                project
                                .split(/[\\/]/)
                                .pop()
                            }
                        </h3>

                        <p>
                            {project}
                        </p>

                    </div>

                ))
}

</div>

        </div>
    );
}

export default WelcomePage;