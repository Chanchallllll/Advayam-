import { useEffect } from "react";
import vscode from "../vscode";

function ProjectDetailsPage({

    projectName,
    setProjectName,

    description,
    setDescription,

    author,
    setAuthor,

    port,

    setPort,

    availablePorts,
    setAvailablePorts,

    projectFolder,
    setProjectFolder,

    errorMessage,
    setErrorMessage,
    prevStep,
    nextStep,
})
{
    useEffect(() =>
    {   
        const listener = (event) =>
        {
            const message = event.data;

            if(message.command === 'folderSelected')
            {
                setProjectFolder(
                    message.path
                );
            }
            if(message.command === 'ports')
            {
            setAvailablePorts(
            message.ports
             );
            }
        };

        window.addEventListener(
            'message',
            listener
        );
        vscode.postMessage({

            command:'getPorts'

        });
        return () =>
        {
            window.removeEventListener(
                'message',
                listener
            );
        };
    }, [setProjectFolder]);

    const handleValidation = () => {
        setErrorMessage('');

        if (!projectName) {
            setErrorMessage('Project Name is required');
            return false;
        }

        if (!description) {
            setErrorMessage('Description is required');
            return false;
        }

        if (!projectFolder) {
            setErrorMessage('Project Folder is required');
            return false;
        }

        return true;
    };

       
    

    const handleSelectFolder = () =>
    {
        if(vscode)
        {
            vscode.postMessage({
                command:'selectFolder'
            });
        }
    };
 

    return(
        <div>
            <div className="project-details-form">
            <h1 style={{marginBottom:'10px', marginTop:'0'}}>
            Project Details
            </h1>
           

                <label>
                    Project Name *
                </label>

                
                <input
                    type="text"
                    value={projectName}
                    maxLength={50}
                    onChange={(e) =>
                        setProjectName(e.target.value)
                    }
                />
                <div style={{fontSize:'12px',textAlign: 'right'}}>
                    {projectName.length}/50
                </div>

            

                <label>
                    Description *
                </label>

                <textarea
                    rows="4"
                    value={description}
                    maxLength={200}
                    onChange={(e) =>
                        setDescription(
                            e.target.value
                        )
                    }
                />
                <div style={{fontSize:'12px',textAlign: 'right'}}>
                    {description.length}/200
                </div>

            

                <label>
                    Author
                </label>

                <input
                    type="text"
                    value={author}
                    maxLength={30}
                    onChange={(e) =>
                        setAuthor(
                            e.target.value
                        )
                    }
                />
                <div style={{fontSize:'12px',textAlign: 'right'}}>
                    {author.length}/30
                </div>
                
                <div className="form-group">

                <label>
                Port
                </label>

                <select
                value={port}
                onChange={(e) =>
                setPort(e.target.value)
                }
                >
                <option value="">

                Select Port

                </option>
                {
                availablePorts.map((item) => (

                <option
                key={item}
                value={item}
                >

                {item}

                </option>

                ))
            }

            </select>

            </div>
            
                <label>
                    Project Folder *
                </label>

                <input
                    type="text"
                    value={projectFolder}
                    placeholder="Click here to select project folder"
                    readOnly
                    onClick={handleSelectFolder}
                    style={{
                        cursor:'pointer'
                    }}
                />

                

           

            {
                errorMessage && (
                    <div
                        style={{
                            color: '#ff4d4f',
                            background: '#fff1f0',
                            border: '1px solid #ffccc7',
                            padding: '10px',
                            borderRadius: '6px',
                            marginTop: '15px',
                            marginBottom: '15px'
                        }}
                    >
                        {errorMessage}
                    </div>
                )
            }
            </div>

            
            

            



            <div className="button-group">

            <button
                type="button"
                onClick={prevStep}
            >
                Back
            </button>

            <button
                type="button"
                onClick={() => {
                    if (handleValidation()) {
                        nextStep();
                    }
                }}
            >
                Next
            </button>

            </div>

        </div>

    );
}


export default ProjectDetailsPage;