import esp32Img from '../assets/ESP32.png';
import arduinoImg from '../assets/Arduino.png';
import reactImg from '../assets/React.png';
import nodejsImg from '../assets/nodejs.png';
import pythonImg from '../assets/Python.png';
function ProjectTypePage({
    selectedType,
    setSelectedType,
    nextStep,
    prevStep
})
{
    const technologies = [
{
    id:'esp32',
    title:'ESP32',
    image:esp32Img
},
{
    id:'arduino',
    title:'Arduino',
    image:arduinoImg
},

{
    id:'micropython',
    title:'MicroPython',
    image:pythonImg
}
];

    return (
        <div>
            <h1>Smart Technology</h1>

            <div className="card-container">
                {technologies.map((tech) => (
                    <div
                        key={tech.id}
                        className={
                            selectedType === tech.id
                                ? "tech-card selected"
                                : "tech-card"
                        }
                        onClick={() => setSelectedType(tech.id)}
                    >
                        <img
                            src={tech.image}
                            alt="tech.title"
                            style={{
                                width: "200px",
                                height: "200px",
                            }}
                        />

                        <h3>{tech.title}</h3>
                    </div>
                ))}
            </div>

            <div className="button-group">
                <button onClick={prevStep}>
                    Back
                </button>

                <button
                    disabled={!selectedType}
                    onClick={nextStep}
                >
                    Next
                </button>
            </div>
        </div>
    );
}

export default ProjectTypePage;