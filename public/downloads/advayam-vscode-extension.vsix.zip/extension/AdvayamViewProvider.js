const vscode = require('vscode');

class AdvayamViewProvider
{
    resolveWebviewView(webviewView)
    {
        webviewView.webview.options =
        {
            enableScripts:true
        };

        webviewView.webview.html = `
        <!DOCTYPE html>
        <html>
        <body>

        <h2>Control Bar</h2>

        <button onclick="build()">
            🔨 Build
        </button>

        <br><br>

        <button onclick="upload()">
            🚀 Upload
        </button>

        <br><br>

        <button onclick="monitor()">
            📟 Monitor
        </button>

        <script>

        const vscode = acquireVsCodeApi();

        function build()
        {
            vscode.postMessage({
                command:'build'
            });
        }

        function upload()
        {
            vscode.postMessage({
                command:'upload'
            });
        }

        function monitor()
        {
            vscode.postMessage({
                command:'monitor'
            });
        }

        </script>

        </body>
        </html>
        `;

        webviewView.webview.onDidReceiveMessage(
            message =>
            {
                const terminal =
                vscode.window.createTerminal(
                    'Advayam'
                );

                terminal.show();

                switch(message.command)
                {
                    case 'build':

                        terminal.sendText(
                            'pio run'
                        );

                        break;

                    case 'upload':

                        terminal.sendText(
                            'pio run --target upload'
                        );

                        break;

                    case 'monitor':

                        terminal.sendText(
                            'pio device monitor'
                        );

                        break;
                }
            }
        );
    }
}

module.exports = AdvayamViewProvider;