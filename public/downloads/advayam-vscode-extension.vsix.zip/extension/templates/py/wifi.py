import network
import socket

SSID = "YOUR_WIFI"
PASSWORD = "YOUR_PASSWORD"

wifi = network.WLAN(network.STA_IF)

wifi.active(True)

wifi.connect(
    SSID,
    PASSWORD
)

while not wifi.isconnected():
    pass

address = socket.getaddrinfo(
    "0.0.0.0",
    80
)[0][-1]

server = socket.socket()

server.bind(address)

server.listen(1)

print("Server running")

while True:

    client, addr = server.accept()

    request = client.recv(1024)

    response = (
        "HTTP/1.1 200 OK\r\n"
        "Content-Type: text/plain\r\n\r\n"
        "Hello from ESP32"
    )

    client.send(response)

    client.close()