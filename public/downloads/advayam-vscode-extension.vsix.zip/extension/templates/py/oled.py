from machine import Pin, SoftI2C
import ssd1306

SCREEN_WIDTH = 128
SCREEN_HEIGHT = 64

i2c = SoftI2C(
    scl=Pin(22),
    sda=Pin(21)
)

display = ssd1306.SSD1306_I2C(
    SCREEN_WIDTH,
    SCREEN_HEIGHT,
    i2c,
    addr=0x3C
)

def setup():

    display.fill(0)

    display.text(
        "Advayam",
        0,
        20
    )

    display.show()

def loop():
    pass


setup()

while True:
    loop()