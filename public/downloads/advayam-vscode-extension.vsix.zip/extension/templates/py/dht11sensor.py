from machine import Pin
import dht
import time

sensor = dht.DHT11(
    Pin(4)
)

print("DHT11 Started")

while True:

    try:

        sensor.measure()

        temp = sensor.temperature()

        hum = sensor.humidity()

        print(
            "Temp:",
            temp,
            "C"
        )

        print(
            "Humidity:",
            hum,
            "%"
        )

    except Exception as error:

        print(
            "Sensor Error:",
            error
        )

    time.sleep(2)