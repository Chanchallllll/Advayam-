import network
from umqtt.simple import MQTTClient

SSID = "YOUR_WIFI"
PASSWORD = "YOUR_PASSWORD"

wifi = network.WLAN(network.STA_IF)

client = MQTTClient(
    "client_id",
    "broker.hivemq.com"
)

def setup():
    print("Setup Complete")

def loop():
    pass


setup()

while True:
    loop()