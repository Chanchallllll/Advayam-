import network
from umqtt.simple import MQTTClient
from time import sleep

SSID = "YOUR_WIFI"
PASSWORD = "YOUR_PASSWORD"

MQTT_BROKER = "broker.hivemq.com"
CLIENT_ID = "MicroPythonClient"

# Connect WiFi
wifi = network.WLAN(network.STA_IF)
wifi.active(True)
wifi.connect(SSID, PASSWORD)

while not wifi.isconnected():
    sleep(1)

print("WiFi Connected")

# Connect MQTT
client = MQTTClient(CLIENT_ID, MQTT_BROKER)
client.connect()

print("MQTT Connected")

while True:
    client.check_msg()
    sleep(1)