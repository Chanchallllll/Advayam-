#include <WiFi.h>
#include <WebServer.h>

const char* ssid = "YOUR_WIFI";
const char* password = "YOUR_PASSWORD";

WebServer server(80);

void handleRoot()
{
    server.send(
        200,
        "text/plain",
        "Hello from ESP32"
    );
}

void setup()
{
    Serial.begin(115200);

    WiFi.begin(
        ssid,
        password
    );

    while(WiFi.status() != WL_CONNECTED)
    {
        delay(500);
    }

    server.on(
        "/",
        handleRoot
    );

    server.begin();
}

void loop()
{
    server.handleClient();
}